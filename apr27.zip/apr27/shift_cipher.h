#ifndef SHIFT_CIPHER_H
#define SHIFT_CIPHER_H

#include <QDialog>

namespace Ui {
class shift_cipher;
}

class shift_cipher : public QDialog
{
    Q_OBJECT

public:
    explicit shift_cipher(QWidget *parent = 0);
    ~shift_cipher();

private slots:
    void on_shift_run_clicked();

private:
    Ui::shift_cipher *ui;
};

#endif // SHIFT_CIPHER_H
