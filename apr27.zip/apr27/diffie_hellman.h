#ifndef DIFFIE_HELLMAN_H
#define DIFFIE_HELLMAN_H

#include <QDialog>

namespace Ui {
class diffie_hellman;
}

class diffie_hellman : public QDialog
{
    Q_OBJECT

public:
    explicit diffie_hellman(QWidget *parent = 0);
    ~diffie_hellman();

private slots:


    void on_pushButton_clicked();

   // void on_label_5_linkActivated(const QString &link);

    void on_pushButton_RUN_clicked();

public:
    Ui::diffie_hellman *ui;
};

#endif // DIFFIE_HELLMAN_H
