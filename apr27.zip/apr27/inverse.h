#ifndef INVERSE_H
#define INVERSE_H

#include <QWidget>

namespace Ui {
class inverse;
}

class inverse : public QWidget
{
    Q_OBJECT

public:
    explicit inverse(QWidget *parent = 0);
    ~inverse();

private slots:
    void on_pushButton_clicked();

private:
    Ui::inverse *ui;
};

#endif // INVERSE_H
