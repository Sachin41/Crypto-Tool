#ifndef SQMSUB2_H
#define SQMSUB2_H

#include<stdio.h>
#include<gmp.h>
#include<string.h>

static char * squareandmultiply_string(char * x, char * y, char * n)
{
    mpz_t z,a,pow,p;
    mpz_init(z);
    mpz_init_set_str(a,x,10);
    mpz_init_set_str(pow,y,10);
    mpz_init_set_str(p,n,10);
    mpz_set_ui(z,(unsigned long int)1);
    unsigned long int len,i;
    char * c=mpz_get_str(NULL,2,pow);
    len=strlen(c);
    for(i=0;i<len;i++)
    {
        mpz_mul(z,z,z);
        mpz_mod(z,z,p);
        if(c[i]=='1')
        {
            mpz_mul(z,z,a);
            mpz_mod(z,z,p);
        }
    }
    char * r=NULL;
    r=mpz_get_str(r,10,z);
    return r;
}

#endif // SQMSUB2_H
