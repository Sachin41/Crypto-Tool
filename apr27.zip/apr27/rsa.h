#ifndef RSA_H
#define RSA_H

#include <QDialog>

namespace Ui {
class RSA;
}

class RSA : public QDialog
{
    Q_OBJECT

public:
    explicit RSA(QWidget *parent = 0);
    ~RSA();

private slots:
    void on_pushButton_clicked();

private:
    Ui::RSA *ui;
};

#endif // RSA_H
