#ifndef KNAPSACK_PROB_SUB1_H
#define KNAPSACK_PROB_SUB1_H
#include<stdio.h>
#include<gmp.h>

struct result
{
    double sum;
    double encrypted;
    double decrypted;
   // unsigned long int weights[];

};

result knapsack(const char *str, const char *arr)
{
    printf("Terms used in the algorithm\n"
            " q = A number greater than Sum of weights"
            " r = a number, such that 0<r<(q-1)"
           "  \n");
    unsigned long int i;
    //char *x1=NULL;
struct result rr;
    mpz_t n,q,g,r,d_y,inverse_r,sum_w,y,temp,arr1;

    mpz_init_set_str(n,str,10);
    gmp_printf("number of items in knapsack problem :%Zd \n\n",n);
    mpz_init(q);
    mpz_init(g);
    mpz_init(r);
    mpz_init(d_y);
    mpz_init(inverse_r);
    mpz_init_set_ui(sum_w,0);
    mpz_init_set_ui(y,0);
    mpz_init_set_ui(temp,0);
    i=mpz_get_ui(n);
    //mpz_t arr1[i];
   // gmp_printf("%Zd\n",n);
   //printf("%lu\n",i);
unsigned long int x[i],b[i],w[i],d_x[i];

    printf("Enter which items are selected in sequence:\n");
    printf("1: selected\n");
    printf("0: not selected\n\n");
    //mpz_init_set_str(arr1,arr,10);
   for(i=0;mpz_cmp_ui(n,i)>0;i++)
    {
     if( arr[i] =='1')
       x[i]=1;
     else
         x[i]=0;
    }
  // printf("%c",arr[i]);
    for(i=0;mpz_cmp_ui(n,i)>0;i++)
    {
        if(i!=0)
            w[i]=w[i-1]*2;
        else
            w[i]=1;
        mpz_add_ui(sum_w,sum_w,w[i]);
    }

    printf("values are as follows :\n\n");
    gmp_printf("======================================================================================================================================== \n");
                                                                // printf("weights are as follows :\n");
    printf("|| Item sequence | Weight | Sum of Weights |    q     |    r      |   Encryption  | inverse_Of_r | Decryption \n");
    gmp_printf("======================================================================================================================================== \n");

    for(i=0;mpz_cmp_ui(n,i)>0;i++)
    {
        printf("||%lu\t",x[i]);
        printf("\t%lu\n",w[i]);
    }
   printf("\n");
                                                            //  for(i=0;mpz_cmp_ui(n,i)>0;i++)
                                                            //{
                                                            // printf("%lu\t",w[i]);
                                                            //   }
                                                    // gmp_printf("\nsum of all the weights is : %Zd\n",sum_w);

    mpz_nextprime(q,sum_w);

    for(i=mpz_get_ui(q)-1;i>0;i--)
    {
        mpz_gcd_ui(g,q,i);
        if(mpz_get_ui(g)==1)
        {
            mpz_set_ui(r,i);
            break;
        }
    }
                                                //  gmp_printf("q (q>sum of all the weights) : %Zd\n",q);
                                                //gmp_printf("r (0<r<=q-1 and gcd(r,q)=0) : %Zd\n",r);

    for(i=0;mpz_cmp_ui(n,i)>0;i++)
    {
        mpz_mul_ui(temp,r,w[i]);
        mpz_mod(temp,temp,q);
        b[i]=mpz_get_ui(temp);
        b[i]=b[i]*x[i];
    }

    for(i=0;mpz_cmp_ui(n,i)>0;i++)
    {
        mpz_add_ui(y,y,b[i]);
    }
    gmp_printf("```````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````` \n");
    printf("value of b (b=r*w mod q)\n");
    for(i=0;mpz_cmp_ui(n,i)>0;i++)
    {
        gmp_printf("%lu\t",b[i]);
    }
    printf("\n");
    gmp_printf("``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````` \n");

    printf("\n");
                                            //gmp_printf("\nEncrypted value : %Zd\n\n",y);

    mpz_invert(inverse_r,r,q);

                                        //gmp_printf("value of r inverse : %Zd\n",inverse_r);

    mpz_mul(temp,inverse_r,y);
    mpz_mod(temp,temp,q);
    mpz_set(d_y,temp);

                                        //gmp_printf("Decrypted value : %Zd\n\n",temp);
    gmp_printf("\n||                                 %Zd           %Zd         %Zd            %Zd           %Zd             %Zd\n",sum_w,q,r,y,inverse_r,temp);


    for(i=mpz_get_ui(n);i>0;i--)
    {
        if(mpz_cmp_ui(d_y,w[i-1])<0)
            d_x[i-1]=0;
        else
            {
                d_x[i-1]=1;
                mpz_sub_ui(d_y,d_y,w[i-1]);
            }
    }

    printf("\nitem sequence obtained by decrypted value :\n");
    for(i=0;mpz_cmp_ui(n,i)>0;i++)
    {
        printf("%lu\t",d_x[i]);
    }
    printf("\n");

    // x1=mpz_get_str(x1,10,y);
    rr.sum=mpz_get_d(sum_w);
    rr.encrypted=mpz_get_d(y);
    rr.decrypted=mpz_get_d(temp);
    gmp_printf("======================================================================================================================================== \n");

    mpz_clear(n);
    mpz_clear(q);
    mpz_clear(r);
    mpz_clear(g);
    mpz_clear(y);
    mpz_clear(d_y);
    mpz_clear(inverse_r);
    mpz_clear(sum_w);
    mpz_clear(temp);

    return rr;
}

#endif // KNAPSACK_PROB_SUB1_H
