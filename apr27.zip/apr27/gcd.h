#ifndef GCD_H
#define GCD_H

#include <QWidget>

namespace Ui {
class gcd;
}

class gcd : public QWidget
{
    Q_OBJECT

public:
    explicit gcd(QWidget *parent = 0);
    ~gcd();

private slots:
    void on_pushButton_clicked();

private:
    Ui::gcd *ui;
};

#endif // GCD_H
