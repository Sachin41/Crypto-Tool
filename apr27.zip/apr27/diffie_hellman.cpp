#include "diffie_hellman.h"
#include "ui_diffie_hellman.h"
//#include "primalitysolvo.h"
#include "mainwindow.h"
//#include "primesub1.h"
//#include "sqmsub2.h"
#include "diffiesub1.h"
diffie_hellman::diffie_hellman(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::diffie_hellman)
{
    ui->setupUi(this);
}

diffie_hellman::~diffie_hellman()
{
    delete ui;
}

void diffie_hellman::on_pushButton_clicked()
{
    MainWindow pushPrm;

    pushPrm.on_pushButton_clicked();

}



void diffie_hellman::on_pushButton_RUN_clicked()
{
    QString n=ui->lineEdit_dfprm->displayText() ;
   std::string st=n.toStdString();
     QString n1=ui->lineEdit_2->displayText() ;
       std::string st1=n1.toStdString();



    /*  int i=primalityss(st.const_iterator );

       if(i==1)
           ui->label_6->setText("Enter NO is prime");
       else
           ui->label_6->setText("Enter no is not prime :-)so enter another num");*/
       char *x;
       x=mydiff(st.c_str(),st1.c_str());
       if(x==NULL)
       {
           ui->label_ascky->setText("Error");
           ui->label_7->setText("Error");
       }
       else
       {
       ui->label_ascky->setText(x);
       ui->label_7->setText(x);
       }

}
