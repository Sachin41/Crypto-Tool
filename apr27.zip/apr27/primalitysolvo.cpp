#include "primalitysolvo.h"
#include "ui_primalitysolvo.h"
#include "primesub1.h"
#include "sqmsub2.h"
#include<string>
#include "diffie_hellman.h"

primalitysolvo::primalitysolvo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::primalitysolvo)
{
    ui->setupUi(this);
}

primalitysolvo::~primalitysolvo()
{
    delete ui;
}

void primalitysolvo::on_pushButton_clicked()
{
    QString n=ui->lineEdit->displayText() ;
    std::string st=n.toStdString();
    int i;
    i=primalityss(st.c_str());
    if(i==1)
        ui->label_3->setText("Prime");
    else
        ui->label_3->setText(":-( Not Prime");
}

void primalitysolvo::on_buttonBox_accepted()
{

}
