#ifndef KNAPSACK_PROB_H
#define KNAPSACK_PROB_H

#include <QDialog>

namespace Ui {
class knapsack_prob;
}

class knapsack_prob : public QDialog
{
    Q_OBJECT

public:
    explicit knapsack_prob(QWidget *parent = 0);
    ~knapsack_prob();

private slots:
    void on_knap_run_clicked();

private:
    Ui::knapsack_prob *ui;
};

#endif // KNAPSACK_PROB_H
