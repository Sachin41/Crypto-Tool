#include "gcd.h"
#include "ui_gcd.h"
#include "gcd1.h"
#include<string>
gcd::gcd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::gcd)
{
    ui->setupUi(this);
}

gcd::~gcd()
{
    delete ui;
}

void gcd::on_pushButton_clicked()
{
    QString n1=ui->lineEdit->displayText() ;
    std::string st=n1.toStdString();
    QString n2=ui->lineEdit_2->displayText() ;
    std::string st2=n2.toStdString();
    //char *i=NULL;
   char *i=gcd1(st.c_str(),st2.c_str());
   /* if(st.c_str()==0 || st2.c_str()==0)
        ui->label_4->setText("0");
    //else if (n1<0 || n2 <0)
            ui->label_4->setText("null");
    else*/
   if(i==NULL)
           ui->label_4->setText("gcd doesn't exist");
   else
   ui->label_4->setText(i);


}
