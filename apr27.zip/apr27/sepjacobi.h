#ifndef SEPJACOBI_H
#define SEPJACOBI_H

#include <QWidget>

namespace Ui {
class Sepjacobi;
}

class Sepjacobi : public QWidget
{
    Q_OBJECT

public:
    explicit Sepjacobi(QWidget *parent = 0);
    ~Sepjacobi();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Sepjacobi *ui;
};

#endif // SEPJACOBI_H
