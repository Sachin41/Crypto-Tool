#ifndef PRIMESUB1_H
#define PRIMESUB1_H

#include<stdio.h>
#include<gmp.h>
#include "jacobi.h"
#include "sqmsub2.h"


inline int primalityss(const char * x)
{
    gmp_randstate_t rs;
    long int n,q;
    char *a1 = NULL, *p1 = NULL;
        long int i,j=3;
        char * r = (char *)malloc(10000*sizeof(char));
    unsigned long int c=1,d=0;
    mpz_t a,res,b,p;
    mpz_init(a);
    mpz_init_set_str(p,x,10);
    mpz_init(res);
    gmp_randinit_mt(rs);
    i=mpz_get_ui(p);
    mpz_init_set_ui(b,(i-1)/2);
    gmp_printf ("a=%Zd\n",a);
            gmp_printf ("p=%Zd\n",p);
    for(i=0;i<j;i++)
    {
        mpz_urandomm(a,rs,p);
        if(mpz_cmp_ui(a,d)==0)
        mpz_set_ui(a,c);
        n=mpz_jacobi(a,p);
        a1=mpz_get_str(a1,10,a);
        p1=mpz_get_str(p1,10,p);
        jacobi(a1,p1);
        r=squareandmultiply_string(mpz_get_str(NULL,10,a),mpz_get_str(NULL,10,b),mpz_get_str(NULL,10,p));
        if(n<0)
        {
        q=mpz_get_ui(p);
        n=q+n;
        }
        mpz_init_set_str(res,r,10);
        if(n==0 || n!=mpz_get_ui(res))
        {
            return -1;
        }
    }
    return 1;
}

#endif // PRIMESUB1_H
