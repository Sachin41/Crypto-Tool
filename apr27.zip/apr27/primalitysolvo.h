#ifndef PRIMALITYSOLVO_H
#define PRIMALITYSOLVO_H

#include <QWidget>

namespace Ui {
class primalitysolvo;
}

class primalitysolvo : public QWidget
{
    Q_OBJECT

public:
    explicit primalitysolvo(QWidget *parent = 0);
    ~primalitysolvo();

public slots:
    void on_pushButton_clicked();

public slots:
    void on_buttonBox_accepted();

public:
    Ui::primalitysolvo *ui;
};

#endif // PRIMALITYSOLVO_H
