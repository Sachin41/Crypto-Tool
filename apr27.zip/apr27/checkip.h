/*#ifndef CHECKIP_H
#define CHECKIP_H

#include<stdio.h>
#include <math.h>
#include<gmp.h>
#include<stdlib.h>
#include <string.h>
#include<limits.h>


int Check(const char *P1,const char *P2,const char *random)
{
    char *Phi=NULL,*c=NULL;
    mpz_t prime1,prime2;
    mpz_t x,y,P;
    mpz_init(prime1);
    mpz_init(prime2);
    mpz_init(x);
    mpz_init(y);
    mpz_init(P);
    int a,b;
    a=primalityss(P1);
    b=primalityss(P2);

    mpz_init_set_str(prime1,P1,10);
    mpz_init_set_str(prime2,P2,10);

    mpz_sub_ui(x,prime1,1);
    mpz_sub_ui(y,prime2,1);
    mpz_mul(P,x,y);

    Phi=mpz_get_str(Phi,10,P);

    c=gcd1(random,Phi);

    int len=strlen(c);
    int d;
    if(len==1 && c[0]=='1')
    {
        d=1;
    }
    else
    {
        d=0;
    }

    if(a==1 && b==1 && d==1)
    {
        return 1;
    }
    else
    {
        return -1;
    }
}

#endif // CHECKIP_H
*/


#ifndef CHECKIP_H
#define CHECKIP_H

#include<stdio.h>
#include <math.h>
#include<gmp.h>
#include<stdlib.h>
#include <string.h>
#include<limits.h>


int Check(const char *P1,const char *P2,const char *random)
{

    char *Phi=NULL,*c=NULL;
    mpz_t prime1,prime2;
    mpz_t x,y,P;
    mpz_init(prime1);
    mpz_init(prime2);
    mpz_init(x);
    mpz_init(y);
    mpz_init(P);
    int a,b;
    a=primalityss(P1);
    b=primalityss(P2);
    gmp_printf("======================================================================================================================================== \n");
    gmp_printf("||  Prime1  |  Prime2  |           phi          |   gcd(random,Phi)   | Encrypted Value | a = inverse(b) | Decryption\n");

    mpz_init_set_str(prime1,P1,10);
    mpz_init_set_str(prime2,P2,10);

    mpz_sub_ui(x,prime1,1);
    mpz_sub_ui(y,prime2,1);
    mpz_mul(P,x,y);

    Phi=mpz_get_str(Phi,10,P);

    c=gcd1(random,Phi);

    int len=strlen(c);
    int d;
    if(len==1 && c[0]=='1')
    {
        d=1;
    }
    else
    {
        d=0;
    }

    if(a==1 && b==1 && d==1)
    {
        printf("||   prime\t   prime\t   %Zd\t       GCD=1",P);
        return 1;
    }
    else
    {

        printf("||Not Prime\tNot Prime\t   %Zd\t\tGCD<>1",P);
        return -1;
    }
}

#endif // CHECKIP_H

