#ifndef SHIFSUB_H
#define SHIFSUB_H

#include<stdio.h>
//#include<conio.h>
#include<string.h>
#include<ctype.h>
#include<gmp.h>


char * shift_enc( const char *p, const char *keych);
char * shift_dec( char *entext, const char *keych);


//ENCRYPTION

char * shift_enc(const char *p,const char *keych)
{
char *j = NULL;
char entext[500];

//strcpy(j,p);

//printf("%s",j);
int i,enc,key;

mpz_t keym,x;
mpz_init_set_str(keym,keych,10);
key=mpz_get_ui(keym);
printf("key=%Zd \n",key);

for(i=0;i<strlen(p);i++)
    {
       if(j[i]==' ')
           {
              entext[i]=' ';
              printf("if part = %c",entext[i]);
       }
            else
           {
           j[i]=tolower(j[i]);
           enc=((j[i]-97)+key)%26;
           entext[i]=enc+97;
           printf("else part = %c",entext[i]);
           }
    }
entext[i]='\0';
printf("cipher= %s \n",entext);
puts(entext);
return entext;
}


//DECRYPTION

/*
char * shift_dec( char *entext, const char *keych1)
{

    int i,dec,key;
    mpz_t keym;
    mpz_init_set_str(keym,keych1,10);
    key=mpz_get_ui(keym);
    char dec1,decr[500];

    for(i=0;i<strlen(entext);i++)
     {
           if(entext[i]==' ')
           {
        decr[i]=' ';
        }
            else
            {
           dec=((entext[i]-97)-key);
            if(dec>=0)
            {
                dec=dec%26;
        }
            else
        {
             dec = (dec - (dec/26)*26)+26;
        }
        dec1= (char) (dec+97);
        decr[i]=dec1;
             }

    }
decr[i]='\0';

    return decr;
} */
#endif // SHIFSUB_H
