#include "knapsack_prob.h"
#include "ui_knapsack_prob.h"
#include "knapsack_prob.h"
#include "knapsack_prob_sub1.h"

/*
struct result
{
    double sum;
    double encrypted;
    double decrypted;
};*/

knapsack_prob::knapsack_prob(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::knapsack_prob)
{
    ui->setupUi(this);
}

knapsack_prob::~knapsack_prob()
{
    delete ui;
}

void knapsack_prob::on_knap_run_clicked()
{
    QString str=ui->lineEdit_n->displayText() ;
   std::string st=str.toStdString();
   int i;
   //unsigned long int w[i];
   int num=0;
    num=str.toInt();
    QString arr=ui->lineEdit_wi->displayText() ;
   std::string st1=arr.toStdString();
   ui->label_itemxi->setText(arr);
   ui->label_decxi->setText(arr);
   QVector<unsigned long int> w(num);
   for(i=0;i<num;i++)
   {
       if(i!=0)
           w[i]=w[i-1]*2;
       else
           w[i]=1;
       w.push_back(i);
   }


QString wei;
   for (int i = 0; i < num; ++i)
   {
       if(i>0)
       wei +=" ";
        wei += QString::number(w[i]);
   }
   ui->label_wi->setText(wei);
    struct result rr = knapsack(st.c_str(),st1.c_str());
    QString s = QString::number(rr.sum, 'd', 8);
    ui->label_sumwi->setText(s);
    QString dec1 = QString::number(rr.decrypted, 'd', 8);
    ui->label_decval->setText(dec1);
    QString enc = QString::number(rr.encrypted, 'd', 8);
    ui->label_encval->setText(enc);

}
/*   int *my_array = new int[num];

   QVariant v1 = QVariant::fromValue( static_cast<void *>(my_array) );
   int *p1 = static_cast<int*>( v1.value<void*>() );
   QVarLengthArray<int> array(num);
   int *w = array.w();
   for (int i = 0; i < 10; ++i)
       w[i] = *p1[i];


  char *item=(char *)malloc(num * sizeof(char));
  item=ui->lineEdit_wi->displayText() ;
  std::string st01=item.toStdString();


   unsigned long int item1=0;
   item1=item.toLong();
   */
