#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include "primalitysolvo.h"
#include"gcd.h"
#include"inverse.h"
#include "diffie_hellman.h"
#include "knapsack_prob.h"
#include "rsa.h"
#include "sepjacobi.h"
#include "shift_cipher.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    primalitysolvo *dialog1;
    gcd *dialog2;
    inverse *dialog3;
    diffie_hellman *dialog4;
    knapsack_prob *dialog7;
    RSA  *dialog8;
    Sepjacobi *dialog5;
    shift_cipher *dialog9;
    //Sepjacobi *dialog5;

public slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private slots:
    void on_pushButton_7_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_11_clicked();

    void on_shift_8_clicked();

private:
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
