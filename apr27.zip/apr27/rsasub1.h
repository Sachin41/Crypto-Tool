/*#ifndef RSASUB1_H
#define RSASUB1_H

#include<stdio.h>
#include <math.h>
#include<gmp.h>
#include<stdlib.h>
#include <string.h>
#include<limits.h>
#include "gcd1.h"
#include "inverse1.h"
#include "primesub1.h"
#include "checkip.h"


char *myRSA(const char *prime1,const char *prime2,const char *num,const char *random,const char *e)
{
    int m1;
    m1=Check(prime1,prime2,random);
    if(m1==-1)
    {
        return "ERROR";
    }

    mpz_t n,x,y,Phi,r;
    mpz_t temp,temp1,temp2,temp3,temp4,m;
    mpz_t p,q,z,b;
    char *a=NULL,*encrypt,*decrypt,*b1=NULL,*Phi1=NULL;
    char *z1=NULL,*n1=NULL,*t=NULL,*temp11=NULL,*temp21=NULL,*n2=NULL;
    mpz_init_set_str(p,prime1,10);
    mpz_init_set_str(q,prime2,10);
    mpz_init_set_str(z,num,10);
    mpz_init_set_str(b,random,10);
    mpz_init(n);
    mpz_init(x);
    mpz_init(y);
    mpz_init(temp);
    mpz_init(temp1);
    mpz_init(temp2);
    mpz_init(temp3);
    mpz_init(temp4);
    mpz_init(Phi);
    mpz_init(r);
    mpz_init(m);


    mpz_mul(n,p,q);

    mpz_sub_ui(x,p,1);
    mpz_sub_ui(y,q,1);
    mpz_mul(Phi,x,y);

    mpz_init_set(temp,b);
    mpz_init_set(temp1,b);
    mpz_set(temp2,Phi);
    b1=mpz_get_str(b1,10,b);
    Phi1=mpz_get_str(Phi1,10,Phi);

    temp11=mpz_get_str(temp11,10,temp1);

    temp21=mpz_get_str(temp21,10,temp2);
    a=modInverse(temp11,temp21);


    int len1=strlen(e);
    int e1;
    if(len1==1 && e[0]=='1')
    {
        e1=1;
    }
    else
    {
        e1=2;
    }
    //Encryption Function
     if(e1==1 || e1==2)
    {
        z1=mpz_get_str(z1,10,z);
        t=mpz_get_str(t,10,temp);
        n1=mpz_get_str(n1,10,n);
        encrypt=squareandmultiply_string(z1,t,n1);
    }

    //Decryption Function
    if(e1==2)
    {
        n2=mpz_get_str(n2,10,n);
        decrypt=squareandmultiply_string(encrypt,a,n2);
    }


    mpz_clear(n);
    mpz_clear(b);
    mpz_clear(x);
    mpz_clear(y);
    mpz_clear(temp);
    mpz_clear(temp1);
    mpz_clear(temp2);
    mpz_clear(temp3);
    mpz_clear(temp4);
    mpz_clear(Phi);
    mpz_clear(r);
    mpz_clear(m);
    if(e1==1)
    return encrypt;
    else
    return decrypt;

}
#endif // RSASUB1_H
*/




#ifndef RSASUB1_H
#define RSASUB1_H

#include<stdio.h>
#include <math.h>
#include<gmp.h>
#include<stdlib.h>
#include <string.h>
#include<limits.h>
#include "gcd1.h"
#include "inverse1.h"
#include "primesub1.h"
#include "checkip.h"


char *myRSA(const char *prime1,const char *prime2,const char *num,const char *random,const char *e)
{
    int m1;
    m1=Check(prime1,prime2,random);
    if(m1==-1)
    {
        return "ERROR";
    }

    mpz_t n,x,y,Phi,r;
    mpz_t temp,temp1,temp2,temp3,temp4,m;
    mpz_t p,q,z,b;
    char *a=NULL,*encrypt,*decrypt,*b1=NULL,*Phi1=NULL;
    char *z1=NULL,*n1=NULL,*t=NULL,*temp11=NULL,*temp21=NULL,*n2=NULL;
    mpz_init_set_str(p,prime1,10);
    mpz_init_set_str(q,prime2,10);
    mpz_init_set_str(z,num,10);
    mpz_init_set_str(b,random,10);
    mpz_init(n);
    mpz_init(x);
    mpz_init(y);
    mpz_init(temp);
    mpz_init(temp1);
    mpz_init(temp2);
    mpz_init(temp3);
    mpz_init(temp4);
    mpz_init(Phi);
    mpz_init(r);
    mpz_init(m);


    mpz_mul(n,p,q);

    mpz_sub_ui(x,p,1);
    mpz_sub_ui(y,q,1);
    mpz_mul(Phi,x,y);

    mpz_init_set(temp,b);
    mpz_init_set(temp1,b);
    mpz_set(temp2,Phi);
    b1=mpz_get_str(b1,10,b);
    Phi1=mpz_get_str(Phi1,10,Phi);

    temp11=mpz_get_str(temp11,10,temp1);

    temp21=mpz_get_str(temp21,10,temp2);
    a=modInverse(temp11,temp21);


    int len1=strlen(e);
    int e1;
    if(len1==1 && e[0]=='1')
    {
        e1=1;
    }
    else
    {
        e1=2;
    }
    //Encryption Function
     if(e1==1 || e1==2)
    {
        z1=mpz_get_str(z1,10,z);
        t=mpz_get_str(t,10,temp);
        n1=mpz_get_str(n1,10,n);
        encrypt=squareandmultiply_string(z1,t,n1);
    }

    //Decryption Function
    if(e1==2)
    {
        n2=mpz_get_str(n2,10,n);
        decrypt=squareandmultiply_string(encrypt,a,n2);
    }
    printf("\t\t%s\t   %s    \t%s\n",encrypt,a,decrypt);
    gmp_printf("======================================================================================================================================== \n");
    mpz_clear(n);
    mpz_clear(b);
    mpz_clear(x);
    mpz_clear(y);
    mpz_clear(temp);
    mpz_clear(temp1);
    mpz_clear(temp2);
    mpz_clear(temp3);
    mpz_clear(temp4);
    mpz_clear(Phi);
    mpz_clear(r);
    mpz_clear(m);
    if(e1==1)
    return encrypt;
    else
    return decrypt;

}
#endif // RSASUB1_H
