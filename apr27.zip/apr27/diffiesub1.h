

#ifndef DIFFIESUB1_H
#define DIFFIESUB1_H
#include<stdio.h>
#include<gmp.h>
void squareandmultiply(mpz_t result,mpz_t base,mpz_t power,mpz_t mod);
int primalityss(mpz_t prim);
void squareandmultiply(mpz_t res,mpz_t a,mpz_t pow,mpz_t p)
{
    mpz_t z;
    mpz_init(z);

    mpz_set_ui(z,(unsigned long int)1);
    unsigned long int len,i;
    char * c=mpz_get_str(NULL,2,pow);
    len=strlen(c);

    for(i=0;i<len;i++)
    {

        mpz_mul(z,z,z);
        mpz_mod(z,z,p);

        if(c[i]=='1')
        {
            mpz_mul(z,z,a);
            mpz_mod(z,z,p);
            //gmp_printf("res= %Zd \n",res);
        }
    }
    mpz_set(res,z);
}
int primalityss(mpz_t p)
{
    gmp_randstate_t rs;
    long int n,q;
        long int i,j=3;
    unsigned long int c=1,d=0;
    mpz_t a,res,b;
    mpz_init(a);
    mpz_init(res);
    gmp_randinit_mt(rs);
    i=mpz_get_ui(p);
    mpz_init_set_ui(b,(i-1)/2);
    for(i=0;i<j;i++)
    {
        mpz_urandomm(a,rs,p);
        if(mpz_cmp_ui(a,d)==0)
        mpz_set_ui(a,c);
        n=mpz_jacobi(a,p);
        squareandmultiply(res,a,b,p);
        if(n<0)
        {
        q=mpz_get_ui(p);
        n=q+n;
        }
        if(n==0 || n!=mpz_get_ui(res))
        {
            return -1;
        }
    }
    return 1;
}


char *mydiff(const char *m,const char *n)
{
    char *dff=NULL;
    int flag=0;
    int ans;
    unsigned long int range;
    mpz_t p,prime,prime1,d1,d2;
    mpz_t g,res,res1,result;
    mpz_t a,b;
    mpz_t x,y;
    mpz_t rand_num;
    //mpz_init(p);
    mpz_init(res);
    mpz_init(res1);
    mpz_init(result);
    mpz_init(a);
    mpz_init(b);
    mpz_init(x);
    mpz_init(y);
    mpz_init(prime1);
    mpz_init(prime);
    //mpz_init(g);
    mpz_init(d1);
    mpz_init(d2);
    mpz_init_set_str(p,m,10);
    mpz_init_set_str(g,n,10);
    gmp_randstate_t rand;
    range = 456789;
    gmp_randinit_mt(rand);
    gmp_randseed_ui(rand,range);
    mpz_init(rand_num);
    mpz_set_ui (d1,1); mpz_set_ui (d2,2);
    int flag2=0;
    do
    {
        //printf("Enter a prime number p\n");
        //gmp_scanf("%Zd",p);
        ans = primalityss(p);
        if(ans == 1)
        {
            flag2=1;
            gmp_printf("======================================================================================================================================== \n");
            gmp_printf ("||\t\t\t   |Prime                     |  primitive root modulo  \n");
            gmp_printf("======================================================================================================================================== \n");
                                                        //   gmp_printf ("%Zd is prime \n", p);
            gmp_printf ("||%Zd \t\t\t   | YES\n",p);
            mpz_mul(prime,p,d2);
                                                         //gmp_printf("2p = %Zd\n",prime);
            mpz_add(prime1,prime,d1);
                                                        //gmp_printf("2p+1 is = %Zd\n",prime1);
            ans = primalityss(prime1);
            if(ans == 1)
            {
                                                           //gmp_printf("%Zd is prime \n", prime1);
                gmp_printf("||2p+1 :%Zd\t\t\t   | YES\n",prime1);

                do
                {

                                                        //			printf("Enter a number for primitive modulo checking less than p :\n");
                                                        //		gmp_scanf("%Zd",g);
                    printf("||\n");
                    squareandmultiply(res,g,d2,p);
                                                         //gmp_printf("%Zd SACHIN\n",res);
                    if(mpz_cmp(res,d1)!=0)
                    {
                        squareandmultiply(res,g,prime1,p);
                        if(mpz_cmp(res,d1)!=0)
                        {
                            flag= 1;
                                                              //gmp_printf("%Zd is primitive modulo\n",g);
                            gmp_printf("||NUM LESS THAN p Chosen :%Zd\t   |\t\t  | YES\n",g);
                            mpz_urandomb(a,rand,19);
                            gmp_printf ("||Sender random number\t \t   | %Zd is \n", a);
                            mpz_urandomb(b,rand,10);
                            gmp_printf ("||Receiver random n\t\t   | %Zd is \n", b);
                            printf("||\n");
                        }
                        else
                        {
                            //gmp_printf("%Zd is not primitive modulo \n",g);
                            gmp_printf("||NUM LESS THAN p :%Zd\t\t\t\t\t|NO\n",g);
                            break;
                        }
                    }
                    else
                    {
                        //gmp_printf("%Zd is not primitive modulo \n",g);
                        gmp_printf("||NUM LESS THAN p :%Zd|\t\t\t\t\t|NO\n",g);

                        break;
                    }
                }while(flag!=1);
            }
            else
            {
                gmp_printf("||2p+1 :%Zd\t\t\t   | NO\n",prime1);
                printf("||Enter other number as 2p+1 is not prime\n");\
                break;

            }
        }
        else
        {
            gmp_printf("||Enter other number as %Zd is not prime \n",p);
            break;

        }

    }while(flag2 !=1);
    if(flag2!=0 && flag!=0)
    {
    squareandmultiply(x,g,a,p);
    gmp_printf ("||Sender computes\t\t   | %Zd \n", x);
    squareandmultiply(y,g,b,p);
    gmp_printf ("||Receiver computes\t\t   | %Zd\n", y);
    squareandmultiply(res,y,a,p);
     printf("||\n");
    printf("||Sender and Receiver share secret :\n" );

    gmp_printf ("||Sender secret\t\t   | %Zd\n", res);
    squareandmultiply(res1,x,b,p);
    gmp_printf ("||Receiver secret\t\t   | %Zd\n", res1);

    dff=mpz_get_str(dff,10,res);
    } //mpz_get_str(dff,10,res1);
    //return 0;
mpz_clear(p);
    mpz_clear(res);
    mpz_clear(res1);
    mpz_clear(result);
    mpz_clear(a);
    mpz_clear(b);
    mpz_clear(x);
    mpz_clear(y);
    mpz_clear(prime1);
    mpz_clear(prime);
    mpz_clear(g);
    mpz_clear(d1);
    mpz_clear(d2);
    mpz_clear(rand_num);
    gmp_printf("======================================================================================================================================== \n");
    return dff;
   }



#endif // DIFFIESUB1_H
