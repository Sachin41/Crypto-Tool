#ifndef INVERSE1_H
#define INVERSE1_H
#include<stdio.h>
#include<gmp.h>
static char *modInverse(const char *r,const char *s)
{
    char *x=NULL;
    mpz_t a,m,m0,mul,t,q;
    mpz_t x0,x1,a0;
    mpz_init_set_str(a,r,10);
    mpz_init_set_str(m,s,10);
    mpz_init_set(m0,m);
    mpz_init_set(a0,a);
    mpz_init_set_ui(x0,0);
    mpz_init_set_ui(x1,1);
    mpz_init(t);
    mpz_init(q);
    mpz_init(mul);
    if (mpz_cmp_ui(m,1)==0)
        return "0";
    while (mpz_cmp_ui(a,1)>0&&mpz_cmp_ui(m,0)>0)
    {
        mpz_tdiv_q(q,a,m);
        mpz_set(t,m);
        mpz_mod(m,a,m);
        mpz_set(a,t);
        mpz_set(t,x0);
        mpz_mul(mul,q,x0);
        mpz_sub(x0,x1,mul);
        mpz_set(x1,t);
    }
    if(mpz_cmp_ui(a,1)!=0)
    {
        gmp_printf("%Zd and %Zd are not Coprime, so Modular Multiplicative Inverse does not exist.\n",a0,m0);
        return NULL;
    }
    if (mpz_cmp_ui(x1,0)<0)
        mpz_add(x1,x1,m0);
    x=mpz_get_str(x,10,x1);
    mpz_clear(m0);
    mpz_clear(a0);
    mpz_clear(t);
    mpz_clear(q);
    mpz_clear(mul);
    mpz_clear(x0);
    mpz_clear(x1);
    mpz_clear(a);
    mpz_clear(m);
    return x;
}
#endif // INVERSE1_H
