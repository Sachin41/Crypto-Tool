#include "inverse.h"
#include "ui_inverse.h"
#include "inverse1.h"
#include <string>

inverse::inverse(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::inverse)
{
    ui->setupUi(this);
}

inverse::~inverse()
{
    delete ui;
}

void inverse::on_pushButton_clicked()
{
    QString n1=ui->invEdit1->displayText() ;
    std::string st1=n1.toStdString();
    QString n2=ui->invEdit2->displayText() ;
    std::string st2=n2.toStdString();
    char *j=modInverse(st1.c_str(),st2.c_str());
    if(j==NULL)
        ui->label_4->setText("Inverse doesn't exist");
    else
        ui->label_4->setText(j);
}
