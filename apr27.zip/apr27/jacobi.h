#ifndef JACOBI_H
#define JACOBI_H

#include<stdio.h>
#include<gmp.h>
inline char *jacobi(const char *a,const char *b)
{
    char *txt= NULL; int loop=1;
    mpz_t m,n,c,res,x,s,t,sign,count,dig,temp,tms;
    mpz_init_set_str(m,a,10);
    mpz_init_set_str(n,b,10);
    mpz_init_set_ui(dig,0);
    mpz_init_set_ui(c,0);
    mpz_init_set_ui(temp,0);
    mpz_init_set_ui(res,0);
    mpz_init_set_ui(x,0);
        mpz_init_set_ui(s,0);
    mpz_init_set_ui(t,0);
    mpz_init_set_ui(count,0);
    mpz_init_set_ui(sign,1);
    mpz_init_set_ui(tms,1);
    gmp_printf("======================================================================================================================================== \n");
    while(!((mpz_cmp_si(res,-1)==0)  || (mpz_cmp_si(res,1)==0)))
    {
        if(mpz_cmp_ui(m,0)<0)
               mpz_mul_si(m,m,-1);

        if(mpz_cmp_ui(n,0)<0)
                     mpz_mul_si(n,n,-1);

        mpz_mod_ui(dig,m,4);
        mpz_mod_ui(temp,n,4);
        gmp_printf("|Loop %d  |       m     |      n    | count of power(k) |x=2/n | s(=pow(2/n,k)) | temp(s*(current)m) |  sign  | Final m value of loop |\n",loop);
        gmp_printf("|`````````|``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````` `|\n");
        if(mpz_cmp_ui(dig,3)==0 && mpz_cmp_ui(temp,3)==0)			//rule4 starts
        {
            mpz_swap(m,n);


            //gmp_printf ("m is %Zd\n",m);
            //gmp_printf ("n is %Zd\n",n);
            mpz_mul_si(m,m,-1);
       }
                else
          mpz_swap(m,n);
           gmp_printf("|Using rule4| %Zd            %Zd                                                                                        \n",m,n);

            mpz_tdiv_q(tms,m,n);							// rule1 starts
           // gmp_printf ("tms and m is %Zd and %Zd\n",tms,m);
            mpz_mul(tms,tms,n);
          //  gmp_printf ("tms is %Zd\n",tms);
            mpz_sub(m,m,tms);
          //  gmp_printf ("m is %Zd\n",m);
            mpz_mod_ui(temp,m,2);
          //  gmp_printf ("temp is %Zd\n",temp);

            gmp_printf("|Using rule1| %Zd             %Zd                                                                                           \n",m,n);

            while(mpz_cmp_ui(temp,0)==0)						//rule3 starts
             {

               mpz_add_ui(count,count,1);

                mpz_tdiv_q_ui(m,m,2);
            //    gmp_printf ("while m and temp is %Zd and %Zd\n",m,temp);
                if(mpz_cmp_ui(m,0)==0)
                break;
                mpz_mod_ui(temp,m,2);
          //      gmp_printf ("while m and temp is %Zd and %Zd\n",m,temp);
             }

        mpz_set(t,m);
        mpz_mod_ui(dig,n,8);
         gmp_printf("|Using rule3| %Zd              %Zd              %Zd                                                                       \n",m,n,count);
        if(mpz_cmp_ui(dig,1)==0 || mpz_cmp_ui(dig,7)==0)			//rule2 starts
            mpz_set_ui(x,1);

        if(mpz_cmp_ui(dig,3)==0 || mpz_cmp_ui(dig,5)==0)
            mpz_set_si(x,-1);
         mpz_pow_ui(s,x,mpz_get_ui(count));

        mpz_mul(temp,s,t);
        mpz_mul(res,temp,sign);
        //gmp_printf ("res is %Zd\n",res);
        if(mpz_cmp_ui(m,0)<0)
            mpz_set_si(sign,-1);
        else
            mpz_set_ui(sign,1);
        mpz_set_ui(count,0);
        //gmp_printf ("In the next loop m = %Zd and n =%Zd\n",m,n);
        loop++;
        gmp_printf("|Using rule2| %Zd             %Zd                       %Zd              %Zd                  %Zd               %Zd           %Zd\n",m,n,x,s,temp,sign,res);

        gmp_printf("`````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````|\n");
    }
    gmp_printf("==============================================================================================================================================\n");
    gmp_printf("The obtained JACOBI SYMBOL by multiplying last temp and previous sign values is : %Zd\n",res);
        txt=mpz_get_str(txt,10,res);
    mpz_clear(dig);
    mpz_clear(c);
    mpz_clear(temp);
    mpz_clear(res);
    mpz_clear(x);
    mpz_clear(t);
    mpz_clear(count);
    mpz_clear(sign);
    mpz_clear(tms);
    return txt;
 }
#endif // JACOBI_H
