#ifndef GCD1_H
#define GCD1_H


#include<stdio.h>
#include<gmp.h>

static char *gcd1(const char *a,const char *b)
{
    char *x=NULL;
    mpz_t r,m,n;
    mpz_init(r);
    mpz_init_set_str(m,a,10);
    mpz_init_set_str(n,b,10);
    if((mpz_cmp_ui(m,0)==0) || (mpz_cmp_ui(n,0)==0))
        return "0";
    else if((mpz_cmp_ui(m,0)<0) || (mpz_cmp_ui(n,0)<0))
        return NULL;
    do
    {
        mpz_mod(r,m,n);
        if(mpz_cmp_ui(r,0)==0)
            break;
        mpz_set(m,n);
        mpz_set(n,r);
    }while(1);
    mpz_clear(r);
    x=mpz_get_str(x,10,n);
    mpz_clear(m);
    mpz_clear(n);
    return x;
}

#endif // GCD1_H
