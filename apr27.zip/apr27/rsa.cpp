#include "rsa.h"
#include "ui_rsa.h"
#include "rsasub1.h"


RSA::RSA(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RSA)
{
    ui->setupUi(this);
}

RSA::~RSA()
{
    delete ui;
}

void RSA::on_pushButton_clicked()
{
    QString p1=ui->lineEdit_p1->displayText() ;
    std::string st=p1.toStdString();
    QString p2=ui->lineEdit_p2->displayText() ;
    std::string st1=p2.toStdString();
    QString num=ui->lineEdit_p3->displayText() ;
    std::string st2=num.toStdString();
    QString r=ui->lineEdit_p4->displayText() ;
    std::string st3=r.toStdString();
    QString e=ui->lineEdit_p5->displayText() ;
    std::string st4=e.toStdString();
    int e1=e.toInt();
    char *res;
    if(e1==1)
    {
        res =myRSA(st.c_str(),st1.c_str(),st2.c_str(),st3.c_str(),st4.c_str());
        ui->label_enc->setText(res);
    }
    else
    {
         res=myRSA(st.c_str(),st1.c_str(),st2.c_str(),st3.c_str(),st4.c_str());
        ui->label_dec->setText(res);
    }



}
