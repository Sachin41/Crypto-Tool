#include "sepjacobi.h"
#include "ui_sepjacobi.h"
#include "jacobi.h"

Sepjacobi::Sepjacobi(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Sepjacobi)
{
    ui->setupUi(this);
}

Sepjacobi::~Sepjacobi()
{
    delete ui;
}

void Sepjacobi::on_pushButton_clicked()
{
    QString m=ui->lineEdit->displayText() ;
    std::string st=m.toStdString();
    QString n=ui->lineEdit_2->displayText() ;
    std::string st1=n.toStdString();
    char *op;
    op=jacobi(st.c_str(),st1.c_str());
    ui->label_3->setText(op);

}
