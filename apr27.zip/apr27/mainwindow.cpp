#include "mainwindow.h"
#include "ui_mainwindow.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    dialog1=new primalitysolvo();
    dialog1->show();
}

void MainWindow::on_pushButton_2_clicked()
{
    dialog2=new gcd();
    dialog2->show();
}

void MainWindow::on_pushButton_3_clicked()
{
    dialog3=new inverse();
    dialog3->show();
}

void MainWindow::on_pushButton_4_clicked()
{
    dialog4=new diffie_hellman();
    dialog4->show();
}

void MainWindow::on_pushButton_7_clicked()
{
    dialog7=new knapsack_prob();
    dialog7->show();
}

void MainWindow::on_pushButton_6_clicked()
{
    dialog8 =new RSA();
    dialog8->show();
}


void MainWindow::on_pushButton_11_clicked()
{
    dialog5 = new Sepjacobi();
    dialog5->show();

}

void MainWindow::on_shift_8_clicked()
{
 dialog9 = new shift_cipher();
 dialog9->show();
}
