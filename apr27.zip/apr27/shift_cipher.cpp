#include "shift_cipher.h"
#include "ui_shift_cipher.h"
#include "shifsub.h"

shift_cipher::shift_cipher(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::shift_cipher)
{
    ui->setupUi(this);
}

shift_cipher::~shift_cipher()
{
    delete ui;
}

void shift_cipher::on_shift_run_clicked()
{
    QString p=ui->lineEdit_plain->displayText();
   std::string st=p.toStdString();
    QString p1=ui->lineEdit_2->displayText();
    //p2=stdtoint
    std::string st1=p1.toStdString();
    char *y;
    y=shift_enc(st.c_str(),st1.c_str());
    ui->label_shiftenc->setText(y);
   // char *z;
    //z=shift_dec()
}
